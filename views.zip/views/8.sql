SELECT english_title
FROM views WHERE artist = "Hokusai" ORDER BY CONTRAST ASC
LIMIT 5;
