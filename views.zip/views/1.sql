SELECT japanese_title , english_title FROM
views;
