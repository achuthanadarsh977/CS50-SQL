SELECT print_number AS print_no FROM
views WHERE artist = "Hokusai" ORDER BY id;
