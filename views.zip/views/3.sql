SELECT COUNT(print_number) FROM views
WHERE english_title LIKE "%Fuji%" AND artist = "Hokusai";
