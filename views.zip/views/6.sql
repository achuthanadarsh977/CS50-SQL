SELECT ROUND(AVG("entropy"),2) AS "Hiroshige Average Entropy"
FROM views WHERE artist = "Hiroshige";
