
-- *** The Lost Letter ***
SELECT * FROM addresses
WHERE address LIKE "900 Somerville Avenue%";

SELECT * FROM addresses
WHERE address LIKE "2 Finn%";

SELECT  * FROM packages
WHERE from_address_id = (SELECT id FROM addresses WHERE address = "900 Somerville Avenue%")
AND to_address_id = (SELECT id FROM addresses WHERE address LIKE "2 Finn%");

SELECT * FROM scans WHERE
package_id = (SELECT id FROM packages WHERE from_address_id = (SELECT id FROM addresses
WHERE address = "900 Somerville Avenue")
AND to_address_id = (SELECT id FROM addresses WHERE address LIKE "2 Finn%"));



-- *** The Forgotten Gift ***
SELECT * FROM addresses WHERE
address LIKE "109 Tileston Street%";

SELECT * FROM addresses WHERE
address LIKE "728 Maple Place%";

SELECT * FROM packages
WHERE from_address_id = (SELECT id FROM addresses WHERE address LIKE "109 Tileston Street%")
AND to_address_id = (SELECT id FROM addresses WHERE address LIKE "728 Maple Place%");

SELECT * FROM drivers
JOIN scans ON drivers.id = scans.driver_id
WHERE scans.address_id = (SELECT id FROM packages WHERE from_address_id = 9873
AND to_address_id = 4983);


SELECT * FROM scans
WHERE package_id = (SELECT id FROM packages
WHERE from_address_id = (SELECT id FROM addresses WHERE address LIKE "109 Tileston Street%")
AND to_address_id = (SELECT id FROM addresses WHERE address LIKE "728 Maple Place%"));

SELECT name FROM drivers
JOIN scans ON drivers.id = scans.driver_id
WHERE scans.package_id = (SELECT id FROM packages
WHERE from_address_id = (SELECT id FROM addresses WHERE address = "109 Tileston Street")
AND to_address_id = (SELECT id FROM addresses WHERE address = "728 Maple Place"));

-- *** The Devious Delivery ***
SELECT * FROM packages
WHERE from_address_id IS NULL;

SELECT addresses.type FROM addresses
JOIN packages ON addresses.id = packages.to_address_id
WHERE packages.contents = "Duck debugger";


