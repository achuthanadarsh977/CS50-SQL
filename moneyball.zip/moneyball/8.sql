SELECT salaries.salary
FROM salaries JOIN performances
ON salaries.player_id = performances.player_id
WHERE salaries.year = 2001 AND
performances.HR IN (SELECT MAX(HR) FROM performances WHERE year = 2001);
