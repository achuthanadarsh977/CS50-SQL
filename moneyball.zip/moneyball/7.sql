SELECT players.first_name , players.last_name
FROM players JOIN salaries ON
players.id = salaries.player_id
WHERE salary IN (SELECT MAX(SALARY) FROM salaries
WHERE team_id IN (SELECT id FROM teams)
);
