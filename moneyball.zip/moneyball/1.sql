SELECT YEAR , ROUND(AVG(salary),2) as AVERAGE_SALARY FROM salaries , players
WHERE players.ID = salaries.player_id
GROUP BY YEAR order BY YEAR DESC;

