SELECT players.first_name , players.last_name ,((salaries.salary)/(performances.H))
as "dollars per hit" FROM salaries JOIN players ON players.id = salaries.player_id
JOIN performances ON performances.year = salaries.year AND performances.player_id = salaries.player_id
WHERE salaries.year = 2001  AND "dollars per hit" IS NOT NULL
ORDER BY "dollars per hit" ,players.first_name ASC , players.last_name ASC
LIMIT 10;
