SELECT players.first_name as "first_name" , players.last_name as "last_name"
FROM players JOIN salaries ON players.id = salaries.player_id
