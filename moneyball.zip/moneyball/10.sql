SELECT players.first_name as "first_name" , players.last_name as "last_name",
salaries.salary as "salary" , performances.HR as "HR",performances.year as "year" FROM performances
JOIN salaries ON performances.year = salaries.year AND performances.player_id = salaries.player_id
JOIN players ON players.id = performances.player_id
ORDER BY players.id ASC ,performances.year DESC , performances.HR DESC , salaries.salary DESC;
