SELECT year , HR from performances , players
WHERE performances.player_id = players.id AND first_name = "Ken" AND last_name = "Griffey" and birth_year = 1969
group by year  order by year desc;
