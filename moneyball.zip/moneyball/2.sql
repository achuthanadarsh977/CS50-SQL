SELECT YEAR , salary FROM salaries , players
WHERE players.ID = salaries.player_id and players.first_name = "Cal" and players.last_name = "Ripken"
GROUP BY YEAR  ORDER BY YEAR DESC;
