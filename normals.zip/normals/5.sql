SELECT MAX("0m")  FROM normals;
