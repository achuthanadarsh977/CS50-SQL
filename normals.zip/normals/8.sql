SELECT "0m","latitude","longitude" FROM normals
WHERE "latitude" = (SELECT MIN("latitude") FROM normals) AND "longitude" = (SELECT MIN("longitude") FROM normals)
ORDER BY latitude ASC
LIMIT 10;
