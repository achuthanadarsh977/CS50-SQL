SELECT "50m"  FROM normals;

