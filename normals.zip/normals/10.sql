SELECT * FROM normals
WHERE latitude = "-180";
