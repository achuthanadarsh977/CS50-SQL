select MIN("0m") FROM normals;
