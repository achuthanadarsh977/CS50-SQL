SELECT "0m" , "100m" , "200m" FROM normals
WHERE latitude = "-78.5"  AND longitude = "-178.5";
