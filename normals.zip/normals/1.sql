SELECT "0m" FROM normals
WHERE latitude = 42.5 and longitude = -69.5;
