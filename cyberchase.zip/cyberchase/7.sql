SELECT title , topic from
episodes WHERE topic LIKE '%fraction%';
