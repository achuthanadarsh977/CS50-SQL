select title from episodes
where topic is NULL;
