select season , title from episodes
where episode_in_season = 1;
