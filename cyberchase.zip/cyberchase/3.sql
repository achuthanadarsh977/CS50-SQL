select production_code from episodes
where title = 'Hackerized!';
