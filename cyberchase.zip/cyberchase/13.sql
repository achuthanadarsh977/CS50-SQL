SELECT id , season , title FROM
episodes WHERE 	air_date BETWEEN '2006-01-01' AND '2014-12-31' OR  air_date BETWEEN '2005-01-01' AND '2015-12-31';
