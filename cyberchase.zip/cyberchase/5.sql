SELECT title from episodes
where air_date = "2004-12-31";
