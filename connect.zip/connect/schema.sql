CREATE TABLE USERS(
    first_and_last_name TEXT NOT NULL,
    USERNAME TEXT NOT NULL,
    PASSWORD TEXT NOT NULL,
    PRIMARY KEY(USERNAME)
);

INSERT INTO USERS VALUES("Alan Garber" , "alan","password");
INSERT INTO USERS VALUES("Reid Hoffman","reid","password");

CREATE TABLE "Schools_and_Universities"(
    NAME TEXT NOT NULL,
    TYPE TEXT NOT NULL CHECK(TYPE IN ("Elementary School", "Middle School", "High School", "Lower School", "Upper School", "College", "University")),
    LOCATION TEXT NOT NULL,
    YEAR INT NOT NULL
);

INSERT INTO "Schools_and_Universities" VALUES("Harvard University","University","Cambridge, Massachusetts",1636);

CREATE TABLE COMPANIES(
    NAME TEXT NOT NULL,
    INDUSTRY TEXT NOT NULL CHECK(INDUSTRY IN("Education","Technology","Finance")),
    LOCATION TEXT NOT NULL
);

INSERT INTO COMPANIES VALUES("LinkedIn","Technology","Sunnyvale, California");

CREATE TABLE Connections(
    school_name TEXT NOT NULL,
    schools_start_date DATE,
    schools_end_date DATE,
    TYPE TEXT NOT NULL CHECK("TYPE" IN ("BA","MA","Phd")),
    name TEXT NOT NULL,
    company_start_date DATE,
    company_end_date DATE,
    TITLE TEXT NOT NULL
);

INSERT INTO Connections VALUES
("Harvard University","1973-09-01","1976-06-01","BA","LinkedIn","2003-01-01","2007-02-01","CEO & Chairman");
